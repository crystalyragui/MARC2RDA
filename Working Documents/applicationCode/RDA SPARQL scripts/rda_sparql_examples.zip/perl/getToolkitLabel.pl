#!/usr/bin/perl
use strict;
use warnings;

use FindBin qw($Bin);
use lib "$FindBin::Bin/../lib";
use M2R::RDF4J qw(rdf4j_query sparql_iri sparql_string DEFAULT_ENDPOINT DEFAULT_LANGCODE);

my $DEBUG = 0;

# $element_iri supports either curie or IRI
my ($element_iri, $langcode, $endpoint) = @ARGV;

die "Usage: $0 <ELEMENT_IRI> [langcode] [endpoint]\n" unless defined $element_iri && length $element_iri;
my $iri = sparql_iri($element_iri);

# NB. RDA Toolkit does not define labels for the subclasses
$iri = check_toolkit_iri($iri);

if (! length $langcode) { $langcode = DEFAULT_LANGCODE; }
$langcode = sparql_string($langcode);

if (! length $endpoint) { $endpoint = DEFAULT_ENDPOINT; }

my $sparql = qq(

SELECT ?element ?elementToolkitLabel
WHERE {
    BIND ( $langcode AS ?language ) 
    { ?element <http://metadataregistry.org/uri/profile/rdakit/toolkitLabel> ?elementToolkitLabel . } 
    VALUES ?element { $iri }
    FILTER( LANGMATCHES(LANG(?elementToolkitLabel), ?language) 
	|| LANGMATCHES(LANG(?elementToolkitLabel), ""))
}

); # qq

my $results = rdf4j_query(
    endpoint => $endpoint,
    sparql   => $sparql,
    format   => 'json',
    method   => 'GET',
    debug    => $DEBUG,
);

print $results;


##################################################################
# NB Toolkit labels are present only in the canonical elements
sub check_toolkit_iri {
    my ($iri) = @_;

    # CURIEs: rdaad:P50002 -> rdaa:P50002
    $iri =~ s/^(rda[a-z])(?:d|o):/$1:/;

    # IRIs: http://rdaregistry.info/Elements/a/object/P50002 -> http://rdaregistry.info/Elements/a/P50002
    $iri =~ s#(/Elements/[a-z])/(datatype|object)/#$1/#i;

    return $iri;
}

