#!/usr/bin/env python3
"""Get an RDA TOOLKIT label for an RDA element IRI."""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib" / "python") )
import re
from m2r.rdf4j import rdf4j_query, sparql_iri, sparql_string, DEFAULT_LANGCODE, DEFAULT_ENDPOINT

DEBUG = False


def toolkit_label_iri(iri: str) -> str:
    """Return canonical RDA element IRI/CURIE for a toolkitLabel lookup."""

    # CURIE form: rdaad:P50002 -> rdaa:P50002
    iri = re.sub(r"^(rda[a-z])[do]:", r"\1:", iri)

    # IRI form: http.../Elements/a/datatype/P50002 -> http.../Elements/a/P50002
    # /Elements/a/object/P50002 -> /Elements/a/P50002
    iri = re.sub(
        r"(/Elements/[a-z])/(datatype|object)/",
        r"\1/",
        iri,
        flags=re.IGNORECASE,
    )

    return iri

def main() -> int:
    """usage: python _get_toolkit_label.py IRI|curie [langcode]"""

    if len(sys.argv) < 2 or len(sys.argv) > 3:
        sys.stderr.write("Usage: " + sys.argv[0] + " ELEMENT_IRI [langcode]\n")
        return 1

    element_iri = sys.argv[1]
    langcode = sys.argv[2] if len(sys.argv) >= 3 and len(sys.argv[2]) else DEFAULT_LANGCODE

    iri = toolkit_label_iri(element_iri)
    iri = sparql_iri(iri)

    langcode = sparql_string(langcode)

    with open('../sparql/toolkit_label_by_element.rq', encoding="utf-8") as x:
        sparql = x.read()

    sparql = sparql.replace("__LANGCODE__", langcode)
    sparql = sparql.replace("__IRI__", iri)

    results = rdf4j_query(
        endpoint=DEFAULT_ENDPOINT,
        sparql=sparql,
        myformat="json",
        method="GET",
        debug=DEBUG,
    )

    sys.stdout.write(results)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
