#!/usr/bin/env python3

"""Get the best access point for an RDA entity IRI."""

# Test IRI: http://marc2rda.info/transform/man#speakingasilence1981reedvolume

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib" / "python") )

from m2r.rdf4j import rdf4j_query, sparql_iri, DEFAULT_ENDPOINT

DEBUG = False

def main() -> int:
    """usage: python get_best_ap.py IRI"""

    if len(sys.argv) != 2:
        sys.stderr.write("Usage: " + sys.argv[0] + " <IRI>\n")
        return 1

    iri = sparql_iri(sys.argv[1])

    sparql = """
PREFIX rdaxo: <http://rdaregistry.info/Elements/x/object/>
PREFIX rdaxd: <http://rdaregistry.info/Elements/x/datatype/>
PREFIX rdax: <http://rdaregistry.info/Elements/x/>
PREFIX rdato: <http://rdaregistry.info/Elements/t/object/>
PREFIX rdatd: <http://rdaregistry.info/Elements/t/datatype/>
PREFIX rdat: <http://rdaregistry.info/Elements/t/>
PREFIX rdapo: <http://rdaregistry.info/Elements/p/object/>
PREFIX rdapd: <http://rdaregistry.info/Elements/p/datatype/>
PREFIX rdap: <http://rdaregistry.info/Elements/p/>
PREFIX rdaio: <http://rdaregistry.info/Elements/i/object/>
PREFIX rdaid: <http://rdaregistry.info/Elements/i/datatype/>
PREFIX rdai: <http://rdaregistry.info/Elements/i/>
PREFIX rdamo: <http://rdaregistry.info/Elements/m/object/>
PREFIX rdamd: <http://rdaregistry.info/Elements/m/datatype/>
PREFIX rdam: <http://rdaregistry.info/Elements/m/>
PREFIX rdaeo: <http://rdaregistry.info/Elements/e/object/>
PREFIX rdaed: <http://rdaregistry.info/Elements/e/datatype/>
PREFIX rdae: <http://rdaregistry.info/Elements/e/>
PREFIX rdawo: <http://rdaregistry.info/Elements/w/object/>
PREFIX rdawd: <http://rdaregistry.info/Elements/w/datatype/>
PREFIX rdaw: <http://rdaregistry.info/Elements/w/>
PREFIX rdand: <http://rdaregistry.info/Elements/n/datatype/>
PREFIX rdan: <http://rdaregistry.info/Elements/n/>
PREFIX rdaao: <http://rdaregistry.info/Elements/a/object/>
PREFIX rdaad: <http://rdaregistry.info/Elements/a/datatype/>
PREFIX rdaa: <http://rdaregistry.info/Elements/a/>
SELECT ?rdaEntity ?bestAccessPoint
WHERE {
{ SELECT ?rdaEntity ?aapString (MAX(?aapStrLen) AS ?aapLen) ?apString ?vapString
WHERE {
{ SELECT ?rdaEntity ?apString (MAX(?apStrLen) AS ?apLen) ?vapString
WHERE {
{ SELECT ?rdaEntity ?vapString (MAX(?vapStrLen) AS ?vapLen) 
WHERE {
BIND(%s AS ?rdaEntity)
OPTIONAL {
{?rdaEntity ?appellation ?personVAP.}
VALUES ?appellation {
rdaw:P10332 rdawd:P10332 rdawo:P10332 rdae:P20314 rdaed:P20314 rdaeo:P20314
rdam:P30295 rdamd:P30295 rdamo:P30295 rdai:P40084 rdaid:P40084 rdaio:P40084
rdaa:P50404 rdaad:P50404 rdaao:P50404 rdaa:P50406 rdaad:P50406 rdaao:P50406
rdaa:P50408 rdaad:P50408 rdaao:P50408 rdaa:P50410 rdaad:P50410 rdaao:P50410
rdaa:P50412 rdaad:P50412 rdaao:P50412 rdap:P70046 rdapd:P70046 rdapo:P70046
rdat:P70048 rdatd:P70048 rdato:P70048 rdax:P00022 rdaxd:P00022 rdaxo:P00022
}
OPTIONAL {
{?personVAP ?nomenString ?vapNomenString.}
VALUES ?nomenString {rdan:P80068 rdand:P80068}
}
}
BIND( COALESCE(
IF( ISIRI(?personVAP), ?vapNomenString, 1/0),
IF( ISLITERAL(?personVAP), ?personVAP, 1/0),
""
)
AS ?vapString)
BIND(STRLEN(?vapString) as ?vapStrLen)
}
GROUP BY ?rdaEntity ?vapStrLen ?vapString
}
OPTIONAL {
{?rdaEntity ?appellation ?personAP.}
VALUES ?appellation {
rdaw:P10328 rdawd:P10328 rdawo:P10328 rdae:P20310 rdaed:P20310 rdaeo:P20310
rdam:P30276 rdamd:P30276 rdamo:P30276 rdai:P40080 rdaid:P40080 rdaio:P40080
rdaa:P50373 rdaad:P50373 rdaao:P50373 rdaa:P50374 rdaad:P50374 rdaao:P50374
rdaa:P50375 rdaad:P50375 rdaao:P50375 rdaa:P50376 rdaad:P50376 rdaao:P50376
rdaa:P50377 rdaad:P50377 rdaao:P50377 rdap:P70018 rdapd:P70018 rdapo:P70018
rdat:P70015 rdatd:P70015 rdato:P70015 rdax:P00016 rdaxd:P00016 rdaxo:P00016
}
OPTIONAL {
{?personAP ?nomenString ?apNomenString.}
VALUES ?nomenString {rdan:P80068 rdand:P80068}
}
}
BIND( COALESCE(
IF( ISIRI(?personAP), ?apNomenString, 1/0),
IF( ISLITERAL(?personAP), ?personAP, 1/0),
""
)
AS ?apString)
BIND(STRLEN(?apString) as ?apStrLen)
}
GROUP BY ?rdaEntity ?apStrLen ?apString ?vapString
}
OPTIONAL {
{?rdaEntity ?appellation ?personAAP.}
VALUES ?appellation {
rdaw:P10331 rdawd:P10331 rdawo:P10331 rdae:P20313 rdaed:P20313 rdaeo:P20313
rdam:P30294 rdamd:P30294 rdamo:P30294 rdai:P40083 rdaid:P40083 rdaio:P40083
rdaa:P50403 rdaad:P50403 rdaao:P50403 rdaa:P50405 rdaad:P50405 rdaao:P50405
rdaa:P50407 rdaad:P50407 rdaao:P50407 rdaa:P50409 rdaad:P50409 rdaao:P50409
rdaa:P50411 rdaad:P50411 rdaao:P50411 rdap:P70045 rdapd:P70045 rdapo:P70045
rdat:P70047 rdatd:P70047 rdato:P70047 rdax:P00020 rdaxd:P00020 rdaxo:P00020
}
OPTIONAL {
{?personAAP ?nomenString ?aapNomenString.}
VALUES ?nomenString {rdan:P80068 rdand:P80068}
}
}
BIND( COALESCE(
IF( ISIRI(?personAAP), ?aapNomenString, 1/0),
IF( ISLITERAL(?personAAP), ?personAAP, 1/0),
""
)
AS ?aapString)
BIND(STRLEN(?aapString) as ?aapStrLen)
}
GROUP BY ?rdaEntity ?aapStrLen ?aapString ?apString ?vapString
}
BIND( COALESCE(
IF (STRLEN(?aapString) > 0, ?aapString, 1/0),
IF (STRLEN(?apString) > 0, ?apString, 1/0),
IF (STRLEN(?vapString) > 0, ?vapString, 1/0)
)
AS ?bestAccessPoint )
}
""" % iri

    results = rdf4j_query(
        endpoint=DEFAULT_ENDPOINT,
        sparql=sparql,
        myformat="json",
        method="POST",
        debug=DEBUG,
    )

    sys.stdout.write(results)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
