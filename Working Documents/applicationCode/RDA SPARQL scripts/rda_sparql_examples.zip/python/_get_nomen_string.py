#!/usr/bin/env python3
"""Get the RDA nomenString for a Nomen IRI."""
# test IRI: http://marc2rda.info/transform/lcsh/plaNom#tasmansea

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib" / "python") )
from m2r.rdf4j import rdf4j_query, sparql_iri, DEFAULT_ENDPOINT

DEBUG = False

def main() -> int:
    """usage: python _get_nomen_string.py IRI"""

    if len(sys.argv) != 2:
        sys.stderr.write("Usage: " + sys.argv[0] + " <IRI>\n")
        return 1

    iri = sparql_iri(sys.argv[1])

    with open('../sparql/nomen_string_by_entity.rq', encoding="utf-8") as x:
        sparql = x.read()

    sparql = sparql.replace("__IRI__", iri)

    results = rdf4j_query(
        endpoint=DEFAULT_ENDPOINT,
        sparql=sparql,
        myformat="json",
        method="GET",
        debug=DEBUG,
    )

    sys.stdout.write(results)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
