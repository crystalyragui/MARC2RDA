package M2R::RDF4J;

#########################################
# /opt/marc2rda/lib/M2R/RDF4J.pm
#########################################

use strict;
use warnings;
use Exporter 'import';
use LWP::UserAgent;
use URI;
use HTTP::Request::Common qw(POST);

use constant API_URL_REMOTE => 'https://marc2rda.info/repository/repositories/';
use constant API_URL_LOCAL => 'http://127.0.0.1:7200/repositories/';
use constant DEFAULT_REPO => 'M2R-PROJECT';
use constant DEFAULT_ENDPOINT => API_URL_REMOTE . DEFAULT_REPO;
use constant DEFAULT_LANGCODE => 'en';

our @EXPORT_OK = qw(
    rdf4j_query 
    run_query
    normalize_iri 
    sparql_iri 
    sparql_string
    expand_curie 
    API_URL_LOCAL
    API_URL_REMOTE
    DEFAULT_ENDPOINT
    DEFAULT_LANGCODE
    DEFAULT_REPO
);

#####################################
sub run_query {
    my (%args);
 
    if (@_ == 1) {
        $args{query} = $_[0];
    } else {
        %args = @_;
    }

    my $sparql = $args{query} // $args{sparql};
    die "run_query requires query or sparql\n" unless defined $sparql;

    return rdf4j_query(
        endpoint => $args{endpoint} // DEFAULT_ENDPOINT,
        sparql   => $sparql,
        format   => $args{format}   // 'json',
        method   => $args{method}   // 'GET',
        debug    => $args{debug}    // 0,
    );
}

######################################
sub rdf4j_query {
    my (%args) = @_;

    my $endpoint = $args{endpoint} || die "Missing endpoint\n";
    my $sparql   = $args{sparql}   || die "Missing SPARQL query\n";
    my $format   = $args{format}   || 'json';
    my $method   = uc($args{method} || 'POST');
    my $debug    = $args{debug}    || 0;

    my $accept = _accept_header_for($format);

    my $ua = LWP::UserAgent->new;
    $ua->timeout(60);
    $ua->env_proxy;

    my $response;

    if ($method eq 'GET') {
        my $uri = URI->new($endpoint);

        $uri->query_form(
            query => $sparql,
        );

        $response = $ua->get(
            $uri,
            Accept => $accept,
        );
    }
    elsif ($method eq 'POST') {
        $response = $ua->request(
            POST(
                $endpoint,
                Content_Type => 'application/sparql-query; charset=UTF-8',
                Accept       => $accept,
                Content      => $sparql,
            )
        );
    }
    else {
        die "Unsupported method: $method. Use GET or POST.\n";
    }

    unless ($response->is_success) {
        die join(
            "\n",
            "RDF4J query failed",
            "HTTP status: " . $response->status_line,
            "Endpoint: $endpoint",
            "Response body:",
            $response->decoded_content,
            ""
        );
    }

    my $results = $response->decoded_content;

    print $results if $debug;

    return $results;
}

#########################################################
sub _accept_header_for {
    my ($format) = @_;

    $format = lc($format || 'json');

    my %accept = (
        json     => 'application/sparql-results+json',
        xml      => 'application/sparql-results+xml',
        csv      => 'text/csv',
        tsv      => 'text/tab-separated-values',

        rdfxml   => 'application/rdf+xml',
        rdf      => 'application/rdf+xml',
        ttl      => 'text/turtle',
        turtle   => 'text/turtle',
        nt       => 'application/n-triples',
        ntriples => 'application/n-triples',
        trig     => 'application/trig',
        jsonld   => 'application/ld+json',
    );

    return $accept{$format} || $format;
}

########################################################
sub normalize_iri {
    my ($iri) = @_;

    die "Missing IRI\n" unless defined $iri;

    $iri =~ s/^\s+//;
    $iri =~ s/\s+$//;

    # Expands curies, eg. rdand:P80068, rdawo:P10312, etc.
    $iri = expand_curie($iri) unless $iri =~ m{^<?https?://};

    # tolerate SPARQL/Turtle style <IRI>
    $iri =~ s/^<//;
    $iri =~ s/>$//;

    die "Bad IRI: contains whitespace [$iri]\n" if $iri =~ /\s/;
    die "Bad IRI: empty\n" unless length $iri;

    return $iri;
}

#########################################################
sub sparql_iri {
    my ($iri) = @_;
    $iri = normalize_iri($iri);
    return "<$iri>";
}

#########################################################
sub sparql_string {
    my ($value) = @_;

    die "Missing string value\n" unless defined $value;

    # Escape backslash first, then double quote
    $value =~ s#\\#\\\\#g;
    $value =~ s#"#\\"#g;

    return '"' . $value . '"';
}


#########################################################
sub expand_curie {
    my ($value) = @_;
    die "Missing CURIE/IRI\n" unless defined $value;

    $value =~ s/^\s+//;
    $value =~ s/\s+$//;
    die "Bad CURIE/IRI: empty\n" unless length $value;

    # Already SPARQL-wrapped IRI: <http://example.org/...>
    if ($value =~ /^<([^<>\s]+)>$/) {
        return $1;
    }

    # Already absolute IRI
    if ($value =~ m{^https?://}) {
        return $value;
    }

    my %CURIE = (
        'rdac:'   => 'http://rdaregistry.info/Elements/c/',
        'rdakit:' => 'http://metadataregistry.org/uri/profile/rdakit/',
        'rdf:'    => 'http://www.w3.org/1999/02/22-rdf-syntax-ns#',
        'rdfs:'   => 'http://www.w3.org/2000/01/rdf-schema#',
        'owl:'    => 'http://www.w3.org/2002/07/owl#',
        'skos:'   => 'http://www.w3.org/2004/02/skos/core#',

        'rdaa:'  => 'http://rdaregistry.info/Elements/a/',
        'rdaao:'  => 'http://rdaregistry.info/Elements/a/object/',
        'rdaad:'  => 'http://rdaregistry.info/Elements/a/datatype/',

        'rdaw:'   => 'http://rdaregistry.info/Elements/w/',
        'rdawo:'  => 'http://rdaregistry.info/Elements/w/object/',
        'rdawd:'  => 'http://rdaregistry.info/Elements/w/datatype/',

        'rdae:'   => 'http://rdaregistry.info/Elements/e/',
        'rdaeo:'  => 'http://rdaregistry.info/Elements/e/object/',
        'rdaed:'  => 'http://rdaregistry.info/Elements/e/datatype/',

        'rdai:'   => 'http://rdaregistry.info/Elements/i/',
        'rdaio:'  => 'http://rdaregistry.info/Elements/i/object/',
        'rdaid:'  => 'http://rdaregistry.info/Elements/i/datatype/',

        'rdam:'   => 'http://rdaregistry.info/Elements/m/',
        'rdamo:'  => 'http://rdaregistry.info/Elements/m/object/',
        'rdamd:'  => 'http://rdaregistry.info/Elements/m/datatype/',

        'rdan:'   => 'http://rdaregistry.info/Elements/n/',
        'rdano:'  => 'http://rdaregistry.info/Elements/n/object/',
        'rdand:'  => 'http://rdaregistry.info/Elements/n/datatype/',

        'rdap:'   => 'http://rdaregistry.info/Elements/p/',
        'rdapo:'  => 'http://rdaregistry.info/Elements/p/object/',
        'rdapd:'  => 'http://rdaregistry.info/Elements/p/datatype/',

        'rdat:'   => 'http://rdaregistry.info/Elements/t/',
        'rdato:'  => 'http://rdaregistry.info/Elements/t/object/',
        'rdatd:'  => 'http://rdaregistry.info/Elements/t/datatype/',

        'rdax:'   => 'http://rdaregistry.info/Elements/x/',
        'rdaxo:'  => 'http://rdaregistry.info/Elements/x/object/',
        'rdaxd:'  => 'http://rdaregistry.info/Elements/x/datatype/',
    );

    if ($value =~ /^([A-Za-z][A-Za-z0-9_-]*:)(.+)$/) {
        my ($prefix, $local) = ($1, $2);

        die "Unknown CURIE prefix: $prefix\n"
            unless exists $CURIE{$prefix};

        die "Bad CURIE local part: empty\n"
            unless length $local;

        die "Bad CURIE local part: contains whitespace [$local]\n"
            if $local =~ /\s/;

        return $CURIE{$prefix} . $local;
    }

    die "Not an absolute IRI and not a recognized CURIE: $value\n";
}

1;

