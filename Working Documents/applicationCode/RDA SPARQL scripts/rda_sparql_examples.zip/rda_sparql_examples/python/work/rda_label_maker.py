#!/usr/bin/env python3
"""
rda_label_maker.py

Ingest an *unzipped* RDA Registry distribution folder and produce TSV tables
for use by a Labels module.

Refined behavior (per user specs):
1) Input is the distribution folder path (required): --path /.../RDA-Vocabularies-X.Y.Z
2) Prefer serialization "nt" if present, otherwise "xml"
3) Parse ONLY:
     <ser>/Elements/*.(nt|xml)
     <ser>/termList/*.(nt|xml)
   Ignore Maps and everything else.
4) Candidate label properties:
   4.1 Elements:  rdakit:toolkitLabel  (fallback to rdfs:label)
   4.2 termList:  skos:prefLabel
   No other properties are considered.
5) Language handling:
   - no --lang: do not filter by language; if multiple labels exist, prefer @en,
     otherwise first available.
   - --lang fr: filter to exactly that language tag; outputs are suffixed _fr by default.
   - --lang all: generate one set per language tag found (plus "und" for no-lang literals).

Outputs are two-column TSV: IRI<TAB>label
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from rdflib import Graph, Literal, Namespace, URIRef
from rdflib.namespace import RDFS, SKOS

RDA_BASE = "http://rdaregistry.info/"
RDAKIT = Namespace("http://metadataregistry.org/uri/profile/rdakit/")


def normalize_rda_element_iri(iri: str) -> str:
    # Collapse datatype/object variants to the base element IRI
    if "/Elements/" in iri:
        iri = iri.replace("/datatype/", "/").replace("/object/", "/")
    return iri


def classify_iri(iri: str) -> Optional[str]:
    if not iri.startswith(RDA_BASE):
        return None
    if "/Elements/" in iri:
        return "elements"
    if "/termList/" in iri:
        return "termlist"
    return None


def choose_serialization_dir(dist_path: Path) -> Tuple[Path, str, str]:
    nt_dir = dist_path / "nt"
    if nt_dir.is_dir():
        return nt_dir, "nt", "*.nt"

    xml_dir = dist_path / "xml"
    if xml_dir.is_dir():
        return xml_dir, "xml", "*.xml"

    raise RuntimeError("No 'nt/' or 'xml/' directory found under the distribution path")


def list_input_files(dist_path: Path) -> Tuple[str, List[Path]]:
    base_dir, fmt, ext = choose_serialization_dir(dist_path)

    elements_dir = base_dir / "Elements"
    termlist_dir = base_dir / "termList"

    element_files = sorted(elements_dir.glob(ext)) if elements_dir.is_dir() else []
    termlist_files = sorted(termlist_dir.glob(ext)) if termlist_dir.is_dir() else []

    if not element_files:
        raise RuntimeError(f"No Elements files found under: {elements_dir}")

    return fmt, element_files + termlist_files


def _lang_of(lit: Literal) -> str:
    return (lit.language or "und").lower()

def _format_literal(lit: Literal, strip_lang: bool) -> str:
    txt = str(lit).strip()
    if strip_lang:
        return txt
    if lit.language:
        return f"{txt}@{lit.language}"
    return txt

def _best_literal(lits: List[Literal], lang: Optional[str]) -> Optional[Literal]:
    if not lits:
        return None

    if lang is None:
        for lit in lits:
            if (lit.language or "").lower() == "en":
                return lit
        return lits[0]

    want = lang.lower()
    for lit in lits:
        if (lit.language or "").lower() == want:
            return lit
    return None


def pick_label_for_elements(g: Graph, s: URIRef, lang: Optional[str], strip_lang: bool = False) -> Optional[str]:
    tl = [o for o in g.objects(s, RDAKIT.toolkitLabel) if isinstance(o, Literal)]
    best = _best_literal(tl, lang)
    if best is not None:
        return _format_literal(best, strip_lang)

    rl = [o for o in g.objects(s, RDFS.label) if isinstance(o, Literal)]
    best = _best_literal(rl, lang)
    if best is not None:
        return _format_literal(best, strip_lang)

    return None


def pick_label_for_termlist(g: Graph, s: URIRef, lang: Optional[str], strip_lang: bool = False) -> Optional[str]:
    pl = [o for o in g.objects(s, SKOS.prefLabel) if isinstance(o, Literal)]
    best = _best_literal(pl, lang)
    if best is not None:
        return _format_literal(best, strip_lang)
    return None


def extract_labels(g: Graph, lang: Optional[str], strip_lang: bool) -> Tuple[Dict[str, str], Dict[str, str]]:
    elements: Dict[str, str] = {}
    termlist: Dict[str, str] = {}

    subjects: Set[URIRef] = set()
    for p in (RDAKIT.toolkitLabel, RDFS.label, SKOS.prefLabel):
        for s in g.subjects(predicate=p):
            if isinstance(s, URIRef):
                subjects.add(s)

    for s in subjects:
        iri_raw = str(s)
        kind = classify_iri(iri_raw)
        if kind is None:
            continue

        if kind == "elements":
            label = pick_label_for_elements(g, s, lang, strip_lang)
            if not label:
                continue
            iri = normalize_rda_element_iri(iri_raw)
            elements.setdefault(iri, label)

        elif kind == "termlist":
            label = pick_label_for_termlist(g, s, lang, strip_lang)
            if not label:
                continue
            termlist.setdefault(iri_raw, label)

    return elements, termlist


def discover_languages(g: Graph) -> List[str]:
    langs: Set[str] = set()
    for p in (RDAKIT.toolkitLabel, RDFS.label, SKOS.prefLabel):
        for o in g.objects(predicate=p):
            if isinstance(o, Literal):
                langs.add(_lang_of(o))
    return sorted(langs)


def write_tsv(path: Path, rows: Dict[str, str]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as f:
        for iri in sorted(rows.keys()):
            label = rows[iri].replace("\t", " ").replace("\r", " ").replace("\n", " ").strip()
            f.write(f"{iri}\t{label}\n")


def suffix_outpath(base: str, lang: str) -> str:
    p = Path(base)
    if p.suffix:
        return str(p.with_name(f"{p.stem}_{lang}{p.suffix}"))
    return f"{base}_{lang}"


def parse_args(argv: List[str]) -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Make Labels-module TSVs from an RDA distribution folder.")
    ap.add_argument("--path", required=True, help="Path to unzipped RDA distribution folder (RDA-Vocabularies-*)")
    ap.add_argument("--lang", default=None, help="Language tag (e.g. en, fr). Use 'all' for per-language outputs.")
    ap.add_argument("--strip-lang", action="store_true", help="Remove language tag (@en, @fr) from labels")
    ap.add_argument("--out-elements", default=None, help="Output TSV for Elements labels (base name)")
    ap.add_argument("--out-terms", default=None, help="Output TSV for termList labels (base name)")
    return ap.parse_args(argv)


def main(argv: List[str]) -> int:
    args = parse_args(argv)

    dist_path = Path(args.path)
    if not dist_path.exists():
        print(f"ERROR: distribution path not found: {dist_path}", file=sys.stderr)
        return 2

    try:
        fmt, files = list_input_files(dist_path)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    g = Graph()
    for f in files:
        g.parse(str(f), format=fmt)

    lang = args.lang.lower() if isinstance(args.lang, str) and args.lang else None

    if lang == "all":
        langs = discover_languages(g)
        if not langs:
            print("ERROR: no language-tagged literals found in candidate properties", file=sys.stderr)
            return 2

        base_elements = args.out_elements or "rda-elements.tsv"
        base_terms = args.out_terms or "rda-terms.tsv"

        for lg in langs:
            elements, termlist = extract_labels(g, None if lg == "und" else lg, args.strip_lang)
            out_elements = Path(suffix_outpath(base_elements, lg))
            out_terms = Path(suffix_outpath(base_terms, lg))
            write_tsv(out_elements, elements)
            write_tsv(out_terms, termlist)
            print(f"Wrote {len(elements)} Element labels to {out_elements}", file=sys.stderr)
            print(f"Wrote {len(termlist)} termList labels to {out_terms}", file=sys.stderr)

        return 0

    elements, termlist = extract_labels(g, lang, args.strip_lang)

    # Output mode:
    # - If neither --out-elements nor --out-terms is provided: write a single combined file "rdalabels.tsv".
    # - Otherwise: write only the explicitly requested outputs.

    if not args.out_elements and not args.out_terms:
        combined_name = "rdalabels.tsv"
        if lang:
            combined_name = suffix_outpath(combined_name, lang)
        combined = {}
        combined.update(elements)
        combined.update(termlist)
        out_combined = Path(combined_name)
        write_tsv(out_combined, combined)
        print(f"Wrote {len(combined)} labels to {out_combined}", file=sys.stderr)
        return 0

    if args.out_elements:
        out_elements_name = args.out_elements
        if lang:
            out_elements_name = suffix_outpath(out_elements_name, lang)
        out_elements = Path(out_elements_name)
        write_tsv(out_elements, elements)
        print(f"Wrote {len(elements)} Element labels to {out_elements}", file=sys.stderr)

    if args.out_terms:
        out_terms_name = args.out_terms
        if lang:
            out_terms_name = suffix_outpath(out_terms_name, lang)
        out_terms = Path(out_terms_name)
        write_tsv(out_terms, termlist)
        print(f"Wrote {len(termlist)} termList labels to {out_terms}", file=sys.stderr)

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
