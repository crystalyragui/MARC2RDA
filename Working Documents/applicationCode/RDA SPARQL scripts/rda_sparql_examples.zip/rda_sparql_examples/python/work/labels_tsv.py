"""
labels_tsv.py - Python replacement for M2R::Labels.pm, with data loaded from a TSV file.

TSV format expected (as in your rdalabels.tsv):
  <IRI><TAB><label-literal>

Examples of label literals the loader can handle:
  "respondent of"@en
  "full screen"
  "something"^^<http://www.w3.org/2001/XMLSchema#string>

API (mirrors the Perl module's intent):
  - has(iri) -> bool
  - get_label(iri) -> str | None
  - get_term(iri) -> str | None
  - labelize_iri(iri) -> str | None  (label if known else original iri)

Notes:
  - Canonicalizes RDA element IRIs by stripping "/datatype/" and "/object/" segments.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Dict, Optional, Tuple
import os
import re


_RDA_ELEMENTS_PREFIX = "http://rdaregistry.info/Elements/"
_TERM_LIST_MARKER = "/termList/"


def _normalize_rda_element_iri(iri: str) -> str:
    # Normalize datatype/object variants to their base element IRI:
    #   .../Elements/a/datatype/P50001  -> .../Elements/a/P50001
    #   .../Elements/a/object/P50001    -> .../Elements/a/P50001
    iri = iri.replace("/datatype/", "/").replace("/object/", "/")
    return iri

_LANG_RE = re.compile(r'^"(?P<txt>.*)"@(?P<lang>[A-Za-z0-9\-]+)$')
_TYPED_RE = re.compile(r'^"(?P<txt>.*)"\^\^<[^>]+>$')
_QUOTED_RE = re.compile(r'^"(?P<txt>.*)"$')


def _parse_tsv_literal(lit: str) -> str:
    """
    Convert a simple Turtle-ish literal form into a plain string label.
    Keeps only the lexical form; discards language/datatype.
    """
    s = lit.strip()

    m = _LANG_RE.match(s)
    if m:
        return m.group("txt")

    m = _TYPED_RE.match(s)
    if m:
        return m.group("txt")

    m = _QUOTED_RE.match(s)
    if m:
        return m.group("txt")

    # Fallback: unquoted text
    return s


@dataclass(frozen=True)
class Labels:
    label: Dict[str, str]
    term: Dict[str, str]


def load_labels_tsv(tsv_path: str | Path) -> Labels:
    """
    Load labels from a TSV file into two dicts:
      - label: RDA element IRIs -> labels
      - term:  termList IRIs    -> labels
    """
    path = Path(tsv_path)
    label: Dict[str, str] = {}
    term: Dict[str, str] = {}

    with path.open("r", encoding="utf-8", errors="replace") as f:
        for raw in f:
            line = raw.strip("\n")
            if not line or line.startswith("#"):
                continue
            if "\t" not in line:
                continue

            iri, lit = line.split("\t", 1)
            lit = lit.strip()

            if not iri:
                continue

            val = _parse_tsv_literal(lit)

            if _TERM_LIST_MARKER in iri:
                term[iri] = val
            elif iri.startswith(_RDA_ELEMENTS_PREFIX):
                # Store both the exact and normalized (datatype/object stripped) key
                base = _normalize_rda_element_iri(iri)
                label[base] = val
                label[iri] = val
            else:
                # keep anything else in label map as-is (harmless)
                label[iri] = val

    return Labels(label=label, term=term)


@lru_cache(maxsize=1)
def _default_db() -> Labels:
    """
    Default load behavior:
      1) If RDA_LABELS_TSV env var set, use it.
      2) Else look for 'rdalabels.tsv' alongside this module.
    """
    env = os.environ.get("RDA_LABELS_TSV", "").strip()
    if env:
        return load_labels_tsv(env)

    here = Path(__file__).resolve().parent
    default = here / "rdalabels.tsv"
    if default.exists():
        return load_labels_tsv(default)

    # If nothing found, load empty maps.
    return Labels(label={}, term={})


def has(iri: str) -> bool:
    if not iri:
        return False
    db = _default_db()
    key = _normalize_rda_element_iri(iri)
    return key in db.label or iri in db.label or iri in db.term


def get_label(iri: str) -> Optional[str]:
    if not iri:
        return None
    db = _default_db()
    key = _normalize_rda_element_iri(iri)
    return db.label.get(key) or db.label.get(iri)


def get_term(iri: str) -> Optional[str]:
    if not iri:
        return None
    db = _default_db()
    return db.term.get(iri)


def labelize_iri(iri: str) -> Optional[str]:
    """
    Return a human-readable label if known, else return the original IRI.
    """
    if not iri:
        return None
    return get_label(iri) or get_term(iri) or iri
