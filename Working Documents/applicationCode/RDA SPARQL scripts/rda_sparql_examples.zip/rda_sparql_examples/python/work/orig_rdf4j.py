"""
Small RDF4J / GraphDB helper module for MARC2RDA Python scripts.

This is a Python refactor of a Perl M2R::RDF4J module.  It delegates
remote SPARQL execution to the third-party SPARQLWrapper package, while
keeping MARC2RDA-specific conveniences such as CURIE expansion and IRI
normalization in one small helper layer.
"""

from __future__ import annotations

import importlib
from typing import Any
from urllib.error import HTTPError, URLError

DEFAULT_ENDPOINT = "https://marc2rda.info/rdf/repositories/M2R-PROJECT"
DEFAULT_LANGCODE = "en"

class RDF4JError(RuntimeError):
    """Raised when an RDF4J / GraphDB query cannot be completed successfully."""


ACCEPT_HEADERS = {
    "json": "application/sparql-results+json",
    "xml": "application/sparql-results+xml",
    "csv": "text/csv",
    "tsv": "text/tab-separated-values",
    "rdfxml": "application/rdf+xml",
    "rdf": "application/rdf+xml",
    "ttl": "text/turtle",
    "turtle": "text/turtle",
    "nt": "application/n-triples",
    "ntriples": "application/n-triples",
    "trig": "application/trig",
    "jsonld": "application/ld+json",
}


CURIE_PREFIXES = {
    "rdac:": "http://rdaregistry.info/Elements/c/",
    "rdakit:": "http://metadataregistry.org/uri/profile/rdakit/",
    "rdf:": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
    "rdfs:": "http://www.w3.org/2000/01/rdf-schema#",
    "owl:": "http://www.w3.org/2002/07/owl#",
    "skos:": "http://www.w3.org/2004/02/skos/core#",
    "rdaa:": "http://rdaregistry.info/Elements/a/",
    "rdaao:": "http://rdaregistry.info/Elements/a/object/",
    "rdaad:": "http://rdaregistry.info/Elements/a/datatype/",
    "rdaw:": "http://rdaregistry.info/Elements/w/",
    "rdawo:": "http://rdaregistry.info/Elements/w/object/",
    "rdawd:": "http://rdaregistry.info/Elements/w/datatype/",
    "rdae:": "http://rdaregistry.info/Elements/e/",
    "rdaeo:": "http://rdaregistry.info/Elements/e/object/",
    "rdaed:": "http://rdaregistry.info/Elements/e/datatype/",
    "rdai:": "http://rdaregistry.info/Elements/i/",
    "rdaio:": "http://rdaregistry.info/Elements/i/object/",
    "rdaid:": "http://rdaregistry.info/Elements/i/datatype/",
    "rdam:": "http://rdaregistry.info/Elements/m/",
    "rdamo:": "http://rdaregistry.info/Elements/m/object/",
    "rdamd:": "http://rdaregistry.info/Elements/m/datatype/",
    "rdan:": "http://rdaregistry.info/Elements/n/",
    "rdano:": "http://rdaregistry.info/Elements/n/object/",
    "rdand:": "http://rdaregistry.info/Elements/n/datatype/",
    "rdap:": "http://rdaregistry.info/Elements/p/",
    "rdapo:": "http://rdaregistry.info/Elements/p/object/",
    "rdapd:": "http://rdaregistry.info/Elements/p/datatype/",
    "rdat:": "http://rdaregistry.info/Elements/t/",
    "rdato:": "http://rdaregistry.info/Elements/t/object/",
    "rdatd:": "http://rdaregistry.info/Elements/t/datatype/",
    "rdax:": "http://rdaregistry.info/Elements/x/",
    "rdaxo:": "http://rdaregistry.info/Elements/x/object/",
    "rdaxd:": "http://rdaregistry.info/Elements/x/datatype/",
}


def accept_header_for(format: str | None = "json") -> str:
    """Return the MIME type used in the HTTP Accept header."""

    key = (format or "json").lower()
    return ACCEPT_HEADERS.get(key, format or "json")


def expand_curie(value: str) -> str:
    """
    Expand a known CURIE to a full IRI.

    Accepts:
    - bare absolute IRIs, e.g. http://example.org/x
    - SPARQL/Turtle-wrapped IRIs, e.g. <http://example.org/x>
    - known MARC2RDA/RDA CURIEs, e.g. rdand:P80068
    """

    if value is None:
        raise ValueError("Missing CURIE/IRI")

    value = value.strip()
    if not value:
        raise ValueError("Bad CURIE/IRI: empty")

    if value.startswith("<") and value.endswith(">"):
        inner = value[1:-1]
        if not inner or any(ch.isspace() for ch in inner) or "<" in inner or ">" in inner:
            raise ValueError(f"Bad wrapped IRI: {value}")
        return inner

    if value.startswith(("http://", "https://")):
        return value

    if ":" in value:
        prefix, local = value.split(":", 1)
        prefix += ":"

        if prefix not in CURIE_PREFIXES:
            raise ValueError(f"Unknown CURIE prefix: {prefix}")
        if not local:
            raise ValueError("Bad CURIE local part: empty")
        if any(ch.isspace() for ch in local):
            raise ValueError(f"Bad CURIE local part: contains whitespace [{local}]")

        return CURIE_PREFIXES[prefix] + local

    raise ValueError(f"Not an absolute IRI and not a recognized CURIE: {value}")


def normalize_iri(iri: str) -> str:
    """
    Normalize a bare IRI, wrapped IRI, or known CURIE to a bare absolute IRI.

    Examples:
        normalize_iri("<http://example.org/x>") -> "http://example.org/x"
        normalize_iri("rdand:P80068") -> "http://rdaregistry.info/Elements/n/datatype/P80068"
    """

    if iri is None:
        raise ValueError("Missing IRI")

    iri = iri.strip()
    if not iri:
        raise ValueError("Bad IRI: empty")

    if not iri.lstrip("<").startswith(("http://", "https://")):
        iri = expand_curie(iri)

    if iri.startswith("<"):
        iri = iri[1:]
    if iri.endswith(">"):
        iri = iri[:-1]

    if any(ch.isspace() for ch in iri):
        raise ValueError(f"Bad IRI: contains whitespace [{iri}]")
    if not iri:
        raise ValueError("Bad IRI: empty")

    return iri


def sparql_iri(iri: str) -> str:
    """Normalize an IRI/CURIE and return it in SPARQL <IRI> form."""

    return f"<{normalize_iri(iri)}>"


def sparql_string(value: str) -> str:
    """Return text escaped for use inside a simple double-quoted SPARQL string."""

    return value.replace("\\", "\\\\").replace('"', '\\"')


def _load_sparqlwrapper_module() -> Any:
    try:
        return importlib.import_module("SPARQLWrapper")
    except ImportError as exc:
        raise RDF4JError(
            "SPARQLWrapper not found. Contact your admin. "
        ) from exc


def _sparqlwrapper_return_format(sw: Any, format: str | None) -> Any:
    """Map friendly format names to SPARQLWrapper return-format constants."""

    key = (format or "json").lower()

    names = {
        "json": "JSON",
        "xml": "XML",
        "csv": "CSV",
        "tsv": "TSV",
        "rdfxml": "RDFXML",
        "rdf": "RDFXML",
        "ttl": "TURTLE",
        "turtle": "TURTLE",
        "n3": "N3",
        "nt": "N3",
        "ntriples": "N3",
        "jsonld": "JSONLD",
    }

    const_name = names.get(key)
    if const_name and hasattr(sw, const_name):
        return getattr(sw, const_name)

    # Last resort: SPARQLWrapper accepts some MIME-type strings directly,
    # and we also set the explicit Accept header below.
    return accept_header_for(format)


def _make_wrapper(
    *,
    endpoint: str | None = DEFAULT_ENDPOINT,
    sparql: str,
    format: str | None = "json",
    method: str | None = "POST",
    timeout: int = 60,
) -> Any:
    """Create and configure a SPARQLWrapper object."""

    if not endpoint:
        raise ValueError("Missing endpoint")
    if not sparql:
        raise ValueError("Missing SPARQL query")

    sw = _load_sparqlwrapper_module()
    wrapper = sw.SPARQLWrapper(endpoint)
    wrapper.setQuery(sparql)
    wrapper.setReturnFormat(_sparqlwrapper_return_format(sw, format))
    wrapper.setTimeout(timeout)
    wrapper.addCustomHttpHeader("Accept", accept_header_for(format))

    method = (method or "POST").upper()
    if method == "GET":
        wrapper.setMethod(sw.GET)
    elif method == "POST":
        wrapper.setMethod(sw.POST)

        # Match the Perl helper's POST behavior: send the SPARQL query text
        # directly in the request body as application/sparql-query.
        if hasattr(sw, "POSTDIRECTLY"):
            wrapper.setRequestMethod(sw.POSTDIRECTLY)
            wrapper.addCustomHttpHeader(
                "Content-Type", "application/sparql-query; charset=UTF-8"
            )
    else:
        raise ValueError(f"Unsupported method: {method}. Use GET or POST.")

    return wrapper


def _decode_response_body(body: bytes | str) -> str:
    if isinstance(body, bytes):
        return body.decode("utf-8", errors="replace")
    return body


def rdf4j_query(
    *,
    endpoint: str,
    sparql: str,
    format: str = "json",
    method: str = "POST",
    debug: bool = False,
    timeout: int = 60,
) -> str:
    """
    Run a SPARQL query against an RDF4J/GraphDB repository and return raw text.

    This mirrors the Perl helper's behavior: the result is the decoded HTTP
    response body, not a Python data structure.  For converted SELECT JSON, use
    rdf4j_query_converted().
    """

    wrapper = _make_wrapper(
        endpoint=endpoint,
        sparql=sparql,
        format=format,
        method=method,
        timeout=timeout,
    )

    try:
        query_result = wrapper.query()
        body = _decode_response_body(query_result.response.read())
    except HTTPError as exc:
        error_body = _decode_response_body(exc.read())
        raise RDF4JError(
            "\n".join(
                [
                    "RDF4J query failed",
                    f"HTTP status: {exc.code} {exc.reason}",
                    f"Endpoint: {endpoint}",
                    "Response body:",
                    error_body,
                ]
            )
        ) from exc
    except URLError as exc:
        raise RDF4JError(f"RDF4J query failed: {exc}") from exc
    except Exception as exc:
        raise RDF4JError(f"RDF4J query failed: {exc}") from exc

    if debug:
        print(body, end="")

    return body


def rdf4j_query_converted(
    *,
    endpoint: str,
    sparql: str,
    format: str = "json",
    method: str = "POST",
    timeout: int = 60,
) -> Any:
    """
    Run a SPARQL query and return SPARQLWrapper's converted result.

    For SELECT + JSON this is normally a Python dict.  For some RDF graph
    formats, SPARQLWrapper may return an rdflib Graph if rdflib is installed.
    """

    wrapper = _make_wrapper(
        endpoint=endpoint,
        sparql=sparql,
        format=format,
        method=method,
        timeout=timeout,
    )

    try:
        return wrapper.query().convert()
    except HTTPError as exc:
        error_body = _decode_response_body(exc.read())
        raise RDF4JError(
            "\n".join(
                [
                    "RDF4J query failed",
                    f"HTTP status: {exc.code} {exc.reason}",
                    f"Endpoint: {endpoint}",
                    "Response body:",
                    error_body,
                ]
            )
        ) from exc
    except URLError as exc:
        raise RDF4JError(f"RDF4J query failed: {exc}") from exc
    except Exception as exc:
        raise RDF4JError(f"RDF4J query failed: {exc}") from exc

