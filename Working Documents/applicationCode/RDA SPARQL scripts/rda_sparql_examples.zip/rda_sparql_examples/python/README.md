# RDF4J Python refactor

Python version of the Perl `M2R::RDF4J` helper module and the `getNomenString.pl` example script.

This version uses `SPARQLWrapper` for the actual SPARQL/RDF4J HTTP call. The local helper code only handles MARC2RDA-specific conveniences such as CURIE expansion and SPARQL IRI normalization.

## Files

- `m2r_rdf4j.py` — helper functions for RDF4J/GraphDB queries and IRI/CURIE handling.
- `get_nomen_string.py` — command-line example that queries `rdand:P80068` for one Nomen IRI.
- `test_m2r_rdf4j.py` — offline sanity tests for the helper functions.

## Dependency

On Ubuntu, prefer the apt-managed package if available:

```bash
sudo apt install python3-sparqlwrapper
```

Then test:

```bash
python3 -c "from SPARQLWrapper import SPARQLWrapper; print('OK')"
```

## Basic use

```bash
python3 get_nomen_string.py 'http://marc2rda.info/transform/nom#example'
```

With an explicit endpoint:

```bash
python3 get_nomen_string.py \
  '<http://marc2rda.info/transform/nom#example>' \
  'https://marc2rda.info/rdf/repositories/M2R-PROJECT'
```

Using POST instead of GET:

```bash
python3 get_nomen_string.py \
  'http://marc2rda.info/transform/nom#example' \
  --method POST
```

Print the raw SPARQL JSON response instead of only the value:

```bash
python3 get_nomen_string.py \
  'http://marc2rda.info/transform/nom#example' \
  --raw
```

## Module use

```python
from m2r_rdf4j import rdf4j_query_converted, sparql_iri

endpoint = "https://marc2rda.info/rdf/repositories/M2R-PROJECT"
iri = sparql_iri("http://marc2rda.info/transform/nom#example")

sparql = f"""
SELECT ?nomenString WHERE {{
  VALUES ?nomen {{ {iri} }}
  ?nomen <http://rdaregistry.info/Elements/n/datatype/P80068> ?nomenString .
}} LIMIT 1
"""

results = rdf4j_query_converted(
    endpoint=endpoint,
    sparql=sparql,
    format="json",
    method="GET",
)

print(results)
```

For Perl-like raw output:

```python
from m2r_rdf4j import rdf4j_query

raw = rdf4j_query(
    endpoint=endpoint,
    sparql=sparql,
    format="json",
    method="GET",
)

print(raw)
```

## CURIE examples

```python
from m2r_rdf4j import expand_curie, sparql_iri

print(expand_curie("rdand:P80068"))
# http://rdaregistry.info/Elements/n/datatype/P80068

print(sparql_iri("rdand:P80068"))
# <http://rdaregistry.info/Elements/n/datatype/P80068>
```

`rdax`, `rdaxo`, and `rdaxd` are included with lowercase `x`.
