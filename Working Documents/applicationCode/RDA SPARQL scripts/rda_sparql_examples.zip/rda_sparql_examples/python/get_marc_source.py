#!/usr/bin/env python3

"""Get the source MARC for an RDA entity IRI."""

import sys
from m2r.rdf4j import rdf4j_query, sparql_iri, DEFAULT_ENDPOINT

DEBUG = False

def main() -> int:
    """usage: python get_marc_source.py IRI"""
    if len(sys.argv) != 2:
        sys.stderr.write("Usage: " + sys.argv[0] + " <IRI>\n")
        return 1

    iri = sparql_iri(sys.argv[1])

    sparql = """
PREFIX rdamd: <http://rdaregistry.info/Elements/m/datatype/>
PREFIX rdaio: <http://rdaregistry.info/Elements/i/object/>
PREFIX rdamo: <http://rdaregistry.info/Elements/m/object/>
PREFIX rdaeo: <http://rdaregistry.info/Elements/e/object/>
PREFIX rdawo: <http://rdaregistry.info/Elements/w/object/>
SELECT ?rdaEntity ?sourceMarc WHERE {
  {?rdaEntity ?hasMetaWork ?metaWork .}
  VALUES ?hasMetaWork { rdawo:P10623 rdaeo:P20576 rdamo:P30462 rdaio:P40164 }
  ?metaWork rdawo:P10072 ?metaManifestation .
  ?metaManifestation rdamd:P30137 ?sourceMarc .
  FILTER( ?rdaEntity = %s )
} LIMIT 1
""" % iri

    results = rdf4j_query(
        endpoint=DEFAULT_ENDPOINT,
        sparql=sparql,
        myformat="json",
        method="POST",
        debug=DEBUG,
    )

    sys.stdout.write(results)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
