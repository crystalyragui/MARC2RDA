#!/usr/bin/env python3
"""Offline sanity tests for m2r_rdf4j.py."""

import unittest
from m2r.rdf4j import _accept_header_for, expand_curie, normalize_iri, sparql_iri


class RDF4JHelperTests(unittest.TestCase):
    def test_accept_header_for_json(self):
        self.assertEqual(_accept_header_for("json"), "application/sparql-results+json")

    def test_accept_header_for_nt(self):
        self.assertEqual(_accept_header_for("nt"), "application/n-triples")

    def test_unknown_format_is_used_as_literal_mime_type(self):
        self.assertEqual(_accept_header_for("application/custom"), "application/custom")

    def test_expand_rdand_curie(self):
        self.assertEqual(
            expand_curie("rdand:P80068"),
            "http://rdaregistry.info/Elements/n/datatype/P80068",
        )

    def test_expand_rdaa_curie(self):
        self.assertEqual(
            expand_curie("rdaa:P50001"),
            "http://rdaregistry.info/Elements/a/P50001",
        )

    def test_expand_rdax_lowercase(self):
        self.assertEqual(
            expand_curie("rdax:P00001"),
            "http://rdaregistry.info/Elements/x/P00001",
        )

    def test_sparql_iri_wraps_bare_iri(self):
        self.assertEqual(sparql_iri("http://example.org/a"), "<http://example.org/a>")

    def test_sparql_iri_normalizes_existing_angle_brackets(self):
        self.assertEqual(sparql_iri("<http://example.org/a>"), "<http://example.org/a>")

    def test_normalize_curie(self):
        self.assertEqual(
            normalize_iri("rdand:P80068"),
            "http://rdaregistry.info/Elements/n/datatype/P80068",
        )


if __name__ == "__main__":
    unittest.main()
