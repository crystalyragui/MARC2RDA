#!/usr/bin/env python3
"""Get an RDA REGISTRY label for an RDA element IRI."""

import sys
from m2r.rdf4j import rdf4j_query, sparql_iri, sparql_string, DEFAULT_LANGCODE, DEFAULT_ENDPOINT

DEBUG = False

def main() -> int:
    """usage: python get_registry_label.py IRI|curie [langcode]"""
    if len(sys.argv) < 2 or len(sys.argv) > 3:
        sys.stderr.write("Usage: " + sys.argv[0] + " <ELEMENT_IRI> [langcode]\n")
        return 1

    element_iri = sys.argv[1]
    langcode = sys.argv[2] if len(sys.argv) >= 3 and len(sys.argv[2]) else DEFAULT_LANGCODE

    iri = sparql_iri(element_iri)
    langcode = sparql_string(langcode)

    sparql = """
SELECT ?element ?elementLabel
WHERE {
    BIND ( %s AS ?language )
    { ?element <http://www.w3.org/2000/01/rdf-schema#label> ?elementLabel . }
    VALUES ?element { %s }
    FILTER( LANGMATCHES(LANG(?elementLabel), ?language)
        || LANGMATCHES(LANG(?elementLabel), ""))
}
""" % (langcode, iri)

    results = rdf4j_query(
        endpoint=DEFAULT_ENDPOINT,
        sparql=sparql,
        myformat="json",
        method="GET",
        debug=DEBUG,
    )

    sys.stdout.write(results)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
