#!/usr/bin/env python3
"""Get the best access point for an RDA entity IRI."""
# Test IRI: http://marc2rda.info/transform/man#speakingasilence1981reedvolume

import sys
from m2r.rdf4j import rdf4j_query, sparql_iri, DEFAULT_ENDPOINT

DEBUG = False

def main() -> int:
    """usage: _get_best_ap.py IRI"""
    if len(sys.argv) != 2:
        sys.stderr.write("Usage: " + sys.argv[0] + " <IRI>\n")
        return 1

    iri = sparql_iri(sys.argv[1])

    with open('../sparql/best_access_point_by_entity.rq', encoding="utf-8") as x:
        sparql = x.read()

    sparql = sparql.replace("__IRI__", iri)

    results = rdf4j_query(
        endpoint=DEFAULT_ENDPOINT,
        sparql=sparql,
        myformat="json",
        method="POST",
        debug=DEBUG,
    )

    sys.stdout.write(results)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
