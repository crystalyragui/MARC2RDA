#!/usr/bin/env python3
"""Get the source MARC for an RDA entity IRI."""

import sys
from m2r.rdf4j import rdf4j_query, sparql_iri, DEFAULT_ENDPOINT

DEBUG = False

def main() -> int:
    """usage: _get_marc_source.py IRI"""

    if len(sys.argv) != 2:
        sys.stderr.write("Usage: " + sys.argv[0] + " <IRI>\n")
        return 1

    iri = sparql_iri(sys.argv[1])

    with open('../sparql/marc_source_by_entity.rq', encoding="utf-8") as x:
        sparql = x.read()

    sparql = sparql.replace("__IRI__", iri)

    results = rdf4j_query(
        endpoint=DEFAULT_ENDPOINT,
        sparql=sparql,
        myformat="json",
        method="POST",
        debug=DEBUG,
    )

    sys.stdout.write(results)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
