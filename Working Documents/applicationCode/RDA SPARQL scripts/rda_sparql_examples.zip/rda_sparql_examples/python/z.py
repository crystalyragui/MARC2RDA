#!/usr/bin/env python3
"""Get the RDA nomenString for a Nomen IRI."""

from __future__ import annotations
import sys

from m2r_rdf4j import rdf4j_query, sparql_iri, DEFAULT_ENDPOINT

DEBUG = False

def main() -> int:
    if len(sys.argv) != 2:
        sys.stderr.write("Usage: " + sys.argv[0] + " <IRI>\n")
        return 1

    iri = sparql_iri(sys.argv[1])

    with open('/opt/marc2rda/sparql/nomen-string-by-entity.rq') as x: sparql = x.read()

    sparql = sparql.replace("__IRI__", iri)

    results = rdf4j_query(
        endpoint=DEFAULT_ENDPOINT,
        sparql=sparql,
        format="json",
        method="GET",
        debug=DEBUG,
    )

    sys.stdout.write(results)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

