echo off
echo To run these tests open a cmd screen in the 'marc2rda' folder
echo Press <Enter> after each script runs to advance to the next one
echo on

cd python

python _get_best_ap.py "http://marc2rda.info/transform/man#speakingasilence1981reedvolume" 
pause
python _get_marc_source.py "http://marc2rda.info/transform/man#speakingasilence1981reedvolume" 
pause
python _get_nomen_string.py "http://marc2rda.info/transform/lcsh/plaNom#tasmansea"
pause
python _get_registry_label.py "http://rdaregistry.info/Elements/e/P20025"
pause
python _get_registry_label.py rdaeo:P20025
pause
python _get_toolkit_label.py "http://rdaregistry.info/Elements/e/P20025"
pause
python _get_toolkit_label.py rdaeo:P20025
pause
python get_best_ap.py "http://marc2rda.info/transform/man#speakingasilence1981reedvolume" 
pause
python get_marc_source.py "http://marc2rda.info/transform/man#speakingasilence1981reedvolume"
pause
python get_nomen_string.py "http://marc2rda.info/transform/lcsh/plaNom#tasmansea"
pause
python get_registry_label.py "http://rdaregistry.info/Elements/e/P20025"
pause
python get_registry_label.py rdaeo:P20025
pause
python get_toolkit_label.py "http://rdaregistry.info/Elements/e/P20025"
pause
python get_toolkit_label.py rdaeo:P20025
pause

cd ..
