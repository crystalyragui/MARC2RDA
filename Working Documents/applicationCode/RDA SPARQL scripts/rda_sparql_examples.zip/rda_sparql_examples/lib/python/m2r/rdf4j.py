"""
Small RDF4J / GraphDB helper module for MARC2RDA Python scripts.

This version intentionally mirrors the Perl M2R::RDF4J module and uses only
Python's standard library.  It does not use SPARQLWrapper.
"""

from __future__ import annotations

from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

PYTHONDONTWRITEBYTECODE="hello"

API_URL_REMOTE = 'https://marc2rda.info/repository/repositories/'
API_URL_LOCAL = 'http://127.0.0.1:7200/repositories/'
DEFAULT_REPO = 'M2R-PROJECT'
DEFAULT_ENDPOINT = API_URL_REMOTE + DEFAULT_REPO
DEFAULT_LANGCODE = 'en'

class RDF4JError(RuntimeError):
    """Raised when an RDF4J / GraphDB query cannot be completed."""

ACCEPT_HEADERS = {
    "json": "application/sparql-results+json",
    "xml": "application/sparql-results+xml",
    "csv": "text/csv",
    "tsv": "text/tab-separated-values",
    "rdfxml": "application/rdf+xml",
    "rdf": "application/rdf+xml",
    "ttl": "text/turtle",
    "turtle": "text/turtle",
    "nt": "application/n-triples",
    "ntriples": "application/n-triples",
    "trig": "application/trig",
    "jsonld": "application/ld+json",
}


CURIE_PREFIXES = {
    "rdac:": "http://rdaregistry.info/Elements/c/",
    "rdakit:": "http://metadataregistry.org/uri/profile/rdakit/",
    "rdf:": "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
    "rdfs:": "http://www.w3.org/2000/01/rdf-schema#",
    "owl:": "http://www.w3.org/2002/07/owl#",
    "skos:": "http://www.w3.org/2004/02/skos/core#",
    "rdaa:": "http://rdaregistry.info/Elements/a/",
    "rdaao:": "http://rdaregistry.info/Elements/a/object/",
    "rdaad:": "http://rdaregistry.info/Elements/a/datatype/",
    "rdaw:": "http://rdaregistry.info/Elements/w/",
    "rdawo:": "http://rdaregistry.info/Elements/w/object/",
    "rdawd:": "http://rdaregistry.info/Elements/w/datatype/",
    "rdae:": "http://rdaregistry.info/Elements/e/",
    "rdaeo:": "http://rdaregistry.info/Elements/e/object/",
    "rdaed:": "http://rdaregistry.info/Elements/e/datatype/",
    "rdai:": "http://rdaregistry.info/Elements/i/",
    "rdaio:": "http://rdaregistry.info/Elements/i/object/",
    "rdaid:": "http://rdaregistry.info/Elements/i/datatype/",
    "rdam:": "http://rdaregistry.info/Elements/m/",
    "rdamo:": "http://rdaregistry.info/Elements/m/object/",
    "rdamd:": "http://rdaregistry.info/Elements/m/datatype/",
    "rdan:": "http://rdaregistry.info/Elements/n/",
    "rdano:": "http://rdaregistry.info/Elements/n/object/",
    "rdand:": "http://rdaregistry.info/Elements/n/datatype/",
    "rdap:": "http://rdaregistry.info/Elements/p/",
    "rdapo:": "http://rdaregistry.info/Elements/p/object/",
    "rdapd:": "http://rdaregistry.info/Elements/p/datatype/",
    "rdat:": "http://rdaregistry.info/Elements/t/",
    "rdato:": "http://rdaregistry.info/Elements/t/object/",
    "rdatd:": "http://rdaregistry.info/Elements/t/datatype/",
    "rdax:": "http://rdaregistry.info/Elements/x/",
    "rdaxo:": "http://rdaregistry.info/Elements/x/object/",
    "rdaxd:": "http://rdaregistry.info/Elements/x/datatype/",
}


__all__ = [
    "rdf4j_query",
    "normalize_iri",
    "sparql_iri",
    "sparql_string",
    "expand_curie",
    "DEFAULT_ENDPOINT",
    "DEFAULT_LANGCODE",
    "RDF4JError",
]


def rdf4j_query(
    *,
    endpoint: str,
    sparql: str,
    myformat: str = "json",
    method: str = "POST",
    debug: bool = False,
    timeout: int = 60,
) -> str:
    """
    Run a SPARQL query against an RDF4J/GraphDB repository.

    This mirrors the Perl helper's behavior: return the decoded HTTP response
    body as raw text, not a Python data structure.
    """

    if not endpoint:
        raise ValueError("Missing endpoint")
    if not sparql:
        raise ValueError("Missing SPARQL query")

    accept = _accept_header_for(myformat)
    method = (method or "POST").upper()

    if method == "GET":
        separator = "&" if "?" in endpoint else "?"
        url = endpoint + separator + urlencode({"query": sparql})
        request = Request(url, headers={"Accept": accept}, method="GET")

    elif method == "POST":
        data = sparql.encode("utf-8")
        request = Request(
            endpoint,
            data=data,
            headers={
                "Content-Type": "application/sparql-query; charset=UTF-8",
                "Accept": accept,
            },
            method="POST",
        )

    else:
        raise ValueError(f"Unsupported method: {method}. Use GET or POST.")

    try:
        with urlopen(request, timeout=timeout) as response:
            body = _decode_response(response.read(), response.headers.get_content_charset())

    except HTTPError as exc:
        error_body = _decode_response(exc.read(), exc.headers.get_content_charset())
        raise RDF4JError(
            "\n".join(
                [
                    "RDF4J query failed",
                    f"HTTP status: {exc.code} {exc.reason}",
                    f"Endpoint: {endpoint}",
                    "Response body:",
                    error_body,
                    "",
                ]
            )
        ) from exc

    except URLError as exc:
        raise RDF4JError(f"RDF4J query failed: {exc}") from exc

    if debug:
        print(body, end="")

    return body


#########################################################
def _accept_header_for(myformat: str | None = "json") -> str:
    myformat = (myformat or "json").lower()
    return ACCEPT_HEADERS.get(myformat, myformat)


########################################################
def normalize_iri(iri: str) -> str:
    """Return an absolute IRI, expanding a recognized CURIE if necessary."""
    if iri is None:
        raise ValueError("Missing IRI")

    iri = iri.strip()

    # Expands curies, eg. rdand:P80068, rdawo:P10312, etc.
    if not (iri.startswith("http://") or iri.startswith("https://")
            or iri.startswith("<http://") or iri.startswith("<https://")):
        iri = expand_curie(iri)

    # tolerate SPARQL/Turtle style <IRI>
    if iri.startswith("<"):
        iri = iri[1:]
    if iri.endswith(">"):
        iri = iri[:-1]

    if any(ch.isspace() for ch in iri):
        raise ValueError(f"Bad IRI: contains whitespace [{iri}]")
    if not iri:
        raise ValueError("Bad IRI: empty")

    return iri


#########################################################
def sparql_iri(iri: str) -> str:
    """Return an IRI normalized and wrapped for use in SPARQL."""
    iri = normalize_iri(iri)
    return f"<{iri}>"


#########################################################
def expand_curie(value: str) -> str:
    """Return an absolute IRI, expanding a recognized CURIE when necessary."""
    if value is None:
        raise ValueError("Missing CURIE/IRI")

    value = value.strip()
    if not value:
        raise ValueError("Bad CURIE/IRI: empty")

    # Already SPARQL-wrapped IRI: <http://example.org/...>
    if value.startswith("<") and value.endswith(">"):
        inner = value[1:-1]
        if not inner or any(ch.isspace() for ch in inner) or "<" in inner or ">" in inner:
            raise ValueError(f"Bad wrapped IRI: {value}")
        return inner

    # Already absolute IRI
    if value.startswith("http://") or value.startswith("https://"):
        return value

    if ":" in value:
        prefix, local = value.split(":", 1)
        prefix = prefix + ":"

        if prefix not in CURIE_PREFIXES:
            raise ValueError(f"Unknown CURIE prefix: {prefix}")
        if not local:
            raise ValueError("Bad CURIE local part: empty")
        if any(ch.isspace() for ch in local):
            raise ValueError(f"Bad CURIE local part: contains whitespace [{local}]")

        return CURIE_PREFIXES[prefix] + local

    raise ValueError(f"Not an absolute IRI and not a recognized CURIE: {value}")

def sparql_string(value: str) -> str:
    """Return a value escaped and quoted as a SPARQL string literal."""

    value = value.replace("\\", "\\\\").replace('"', '\\"')
    return '"' + value + '"'

def _decode_response(body: bytes, charset: str | None = None) -> str:
    return body.decode(charset or "utf-8", errors="replace")
