#!/usr/bin/perl
use strict;
use warnings;

my ($file) = @ARGV;
open my $fh, '<', $file or die "Cannot open $file: $!";

my @lines;
while (my $line = <$fh>) {
   $line =~ s/[\r\n]+\z//;
   next if $line =~ /^\s*$/;
   push @lines, $line;
}
close $fh;

my $prefixes = join "\n", @lines;
print "$prefixes \n";

