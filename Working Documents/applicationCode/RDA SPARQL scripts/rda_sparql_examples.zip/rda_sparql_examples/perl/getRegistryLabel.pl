#!/usr/bin/perl
use strict;
use warnings;

use FindBin qw($Bin);
use lib "$FindBin::Bin/../lib";
use M2R::RDF4J qw(rdf4j_query sparql_string sparql_iri DEFAULT_ENDPOINT DEFAULT_LANGCODE);

my $DEBUG = 0;

# $element_iri supports either curie or IRI
my ($element_iri, $langcode, $endpoint) = @ARGV;

die "Usage: $0 <ELEMENT_IRI> [langcode] [endpoint]\n" unless defined $element_iri && length $element_iri;
my $iri = sparql_iri($element_iri);

if (! length $langcode) { $langcode = DEFAULT_LANGCODE; }
$langcode = sparql_string($langcode);

if (! length $endpoint) { $endpoint = DEFAULT_ENDPOINT; }

my $sparql = qq(

SELECT ?element ?elementRegistryLabel
WHERE {
    BIND ( $langcode AS ?language ) 
    { ?element <http://www.w3.org/2000/01/rdf-schema#label> ?elementRegistryLabel . }
    VALUES ?element { $iri }
    FILTER( LANGMATCHES(LANG(?elementRegistryLabel), ?language) 
	|| LANGMATCHES(LANG(?elementRegistryLabel), ""))
}

);

my $results = rdf4j_query(
    endpoint => $endpoint,
    sparql   => $sparql,
    format   => 'json',
    method   => 'GET',
    debug    => $DEBUG,
);

print $results;
