#!/usr/bin/perl
use strict;
use warnings;

use FindBin qw($Bin);
use lib "$FindBin::Bin/../lib";
use M2R::RDF4J qw(rdf4j_query sparql_iri DEFAULT_ENDPOINT);

my $DEBUG = 0;

my ($iri, $endpoint) = @ARGV;
die "Usage: $0 <IRI> [endpoint]\n" unless defined $iri && length $iri;

$iri = sparql_iri($iri);
if (! length $endpoint) { $endpoint = DEFAULT_ENDPOINT; }

use IO::All;
my $sparql < io '../sparql/marc_source_by_entity.rq';
$sparql =~ s/__IRI__/$iri/;

my $results = rdf4j_query(
    endpoint => $endpoint,
    sparql   => $sparql,
    format   => 'json',
    method   => 'POST',
    debug    => $DEBUG,
);

print $results;

