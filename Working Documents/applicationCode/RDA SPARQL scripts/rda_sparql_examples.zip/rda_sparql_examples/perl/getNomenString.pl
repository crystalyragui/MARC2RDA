#!/usr/bin/perl
use strict;
use warnings;

use FindBin qw($Bin);
use lib "$FindBin::Bin/../lib";
use M2R::RDF4J qw(rdf4j_query sparql_iri DEFAULT_ENDPOINT);

my $DEBUG = 0;

# test IRI: http://marc2rda.info/transform/lcsh/plaNom#tasmansea
my ($iri, $endpoint) = @ARGV;
die "Usage: $0 <IRI> [endpoint]\n" unless defined $iri && length $iri;

$iri = sparql_iri($iri);
if (! length $endpoint) { $endpoint = DEFAULT_ENDPOINT; }

my $sparql = qq(

SELECT ?nomenString WHERE { 
 VALUES ?nomen { $iri }
 ?nomen <http://rdaregistry.info/Elements/n/datatype/P80068> ?nomenString . 
} LIMIT 1

);

my $results = rdf4j_query(
    endpoint => $endpoint,
    sparql   => $sparql,
    format   => 'json',
    method   => 'GET',
    debug    => $DEBUG,
);

print $results;

