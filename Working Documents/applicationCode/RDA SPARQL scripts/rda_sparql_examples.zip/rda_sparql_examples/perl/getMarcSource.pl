#!/usr/bin/perl
use strict;
use warnings;

use FindBin qw($Bin);
use lib "$FindBin::Bin/../lib";
use M2R::RDF4J qw(rdf4j_query sparql_iri DEFAULT_ENDPOINT);

my $DEBUG = 0;

# test IRI: http://marc2rda.info/transform/man#speakingasilence1981reedvolume
my ($iri, $endpoint) = @ARGV;
die "Usage: $0 <IRI> [endpoint]\n" unless defined $iri && length $iri;

$iri = sparql_iri($iri);
if (! length $endpoint) { $endpoint = DEFAULT_ENDPOINT; }

my $sparql = qq(

PREFIX rdamd: <http://rdaregistry.info/Elements/m/datatype/>
PREFIX rdaio: <http://rdaregistry.info/Elements/i/object/>
PREFIX rdamo: <http://rdaregistry.info/Elements/m/object/>
PREFIX rdaeo: <http://rdaregistry.info/Elements/e/object/>
PREFIX rdawo: <http://rdaregistry.info/Elements/w/object/>
SELECT ?rdaEntity ?sourceMarc WHERE {
  {?rdaEntity ?hasMetaWork ?metaWork .}
  VALUES ?hasMetaWork { rdawo:P10623 rdaeo:P20576 rdamo:P30462 rdaio:P40164 }
  ?metaWork rdawo:P10072 ?metaManifestation .
  ?metaManifestation rdamd:P30137 ?sourceMarc .
  FILTER( ?rdaEntity = $iri )
} LIMIT 1

);

my $results = rdf4j_query(
    endpoint => $endpoint,
    sparql   => $sparql,
    format   => 'json',
    method   => 'POST',
    debug    => $DEBUG,
);

print $results;

