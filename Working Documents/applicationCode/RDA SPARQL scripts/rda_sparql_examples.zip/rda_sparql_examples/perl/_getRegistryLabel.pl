#!/usr/bin/perl
use strict;
use warnings;
use IO::All;

use FindBin qw($Bin);
use lib "$FindBin::Bin/../lib";
use M2R::RDF4J qw(rdf4j_query sparql_iri sparql_string DEFAULT_ENDPOINT DEFAULT_LANGCODE);

my $DEBUG = 0;

my ($element_iri, $langcode, $endpoint) = @ARGV;

die "Usage: $0 <ELEMENT_IRI> [langcode] [endpoint]\n" unless defined $element_iri && length $element_iri;
my $iri = sparql_iri($element_iri);

if (! length $langcode) { $langcode = DEFAULT_LANGCODE; }
$langcode = sparql_string($langcode);

if (! length $endpoint) { $endpoint = DEFAULT_ENDPOINT; }

my $sparql < io '../sparql/registry_label_by_element.rq';
$sparql =~ s/__LANGCODE__/$langcode/;
$sparql =~ s/__IRI__/$iri/;
print "$sparql \n" if ($DEBUG);

my $results = rdf4j_query(
    endpoint => $endpoint,
    sparql   => $sparql,
    format   => 'json',
    method   => 'GET',
    debug    => $DEBUG,
);

print $results;
