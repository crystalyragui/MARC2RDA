echo off
echo To run these tests open a cmd screen in the 'rda_sparql_examples' folder
echo on

cd perl

perl -w _getBestAP.pl "http://marc2rda.info/transform/man#speakingasilence1981reedvolume" | perl -ne "print if /Speaking a silence/"
pause
perl -w _getMarcSource.pl "http://marc2rda.info/transform/man#speakingasilence1981reedvolume" | perl -ne "print if /F  00905cam a2200301 a 4500/"
pause
perl -w _getNomenString.pl "http://marc2rda.info/transform/lcsh/plaNom#tasmansea"
pause
perl -w _getRegistryLabel.pl "http://rdaregistry.info/Elements/e/P20025"
pause
perl -w _getRegistryLabel.pl rdaeo:P20025
pause
perl -w _getToolkitLabel.pl "http://rdaregistry.info/Elements/e/P20025"
pause
perl -w _getToolkitLabel.pl rdaeo:P20025
pause
perl -w getBestAP.pl "http://marc2rda.info/transform/man#speakingasilence1981reedvolume" | perl -ne "print if /Speaking a silence/"
pause
perl -w getMarcSource.pl "http://marc2rda.info/transform/man#speakingasilence1981reedvolume"
pause
perl -w getNomenString.pl "http://marc2rda.info/transform/lcsh/plaNom#tasmansea"
pause
perl -w getRegistryLabel.pl "http://rdaregistry.info/Elements/e/P20025"
pause
perl -w getRegistryLabel.pl rdaeo:P20025
pause
perl -w getToolkitLabel.pl "http://rdaregistry.info/Elements/e/P20025"
pause
perl -w getToolkitLabel.pl rdaeo:P20025
pause

cd ..
